# Publicacion en GitHub Pages

Este proyecto puede publicarse como sitio estatico desde la carpeta `docs/`.

## Generar el sitio

```bash
npm run static:build
```

El comando crea:

- `docs/index.html`: version para GitHub Pages.
- `docs/.nojekyll`: evita que GitHub procese la carpeta con Jekyll.
- `docs/vendor/`: librerias locales de MapLibre GL JS y Turf.js.
- `outputs/sen-lupa-estatico/index.html`: copia local para abrir/probar.

## Configurar GitHub Pages

1. Sube este repositorio a GitHub.
2. En GitHub, entra a `Settings > Pages`.
3. En `Build and deployment`, elige `Deploy from a branch`.
4. Selecciona la rama principal y la carpeta `/docs`.
5. Guarda. GitHub publicara una URL del tipo:

```text
https://usuario.github.io/repositorio/
```

## Notas

- El HTML contiene embebidos `sen-data.json` y `chile.geojson`, por lo que GitHub Pages no necesita backend.
- La visualizacion usa MapLibre GL JS y Turf.js desde `docs/vendor/`, por lo que no depende de CDN para cargar la app.
- Cuando actualices el KMZ o los datos CEN historicos, regenera el HTML con `npm run static:build` y vuelve a subir los cambios.

## Actualizacion automatica CEN

El workflow `.github/workflows/update-cen-data.yml` ejecuta cada 15 minutos:

```bash
npm run cen:update
```

Ese comando descarga datos desde la API del Coordinador y actualiza:

- `docs/data/status.json`
- `docs/data/cmg-online-latest.json`
- `docs/data/cmg-real-latest.json`
- `docs/data/demanda-real-estimada.json`
- `docs/data/embalse-real-last.json`

En GitHub puedes configurar:

- `Settings > Secrets and variables > Actions > Variables`
  - `CEN_API_BASE_URL`: URL base de la API. Valor sugerido: `https://api.coordinador.cl`.
- `Settings > Secrets and variables > Actions > Secrets`
  - `CEN_API_KEY`: llave API del portal del Coordinador, si tu plan la requiere.

Tambien puedes ejecutar la actualizacion manual desde `Actions > Actualizar datos CEN > Run workflow`.

La interfaz lee `docs/data/cmg-online-latest.json`. Si encuentra barras coincidentes con el KMZ, reemplaza la capa simulada de CMg por datos CEN online. Si no hay datos o falla la API, mantiene la capa preparada para que el mapa no quede inutilizable.
